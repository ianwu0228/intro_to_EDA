#include "routing.h"
#include <deque>

int main(int argc, char* argv[]) {
    int rows = 0, cols = 0;
    Maze* maze = nullptr;

    ifstream fin;
	ofstream fout;
	fin.open(argv[1]);
	fout.open(argv[2]);
    
    parse_input(fin, rows, cols, maze);

    maze->init_pins();

    vector<int> net_indices(maze->nets.size());
    for (size_t i = 0; i < net_indices.size(); ++i)
        net_indices[i] = i;
    
    sort(net_indices.begin(), net_indices.end(), [&](int a, int b) {
        return maze->nets[a].hpwl() < maze->nets[b].hpwl();
    });

    deque<int> route_queue(net_indices.begin(), net_indices.end());
    
    while (!route_queue.empty()) {
        int net_idx = route_queue.front();
        route_queue.pop_front();

        // 1. Try standard legal routing
        if (maze->route_net_a_star(net_idx)) {
            maze->commit_net(net_idx);
        } 
        else {
            // 2. Failed: Force route, identify victims, and increase history costs
            set<int> victims_ids = maze->route_force(net_idx);
            
            // If force failed (e.g. completely walled off by static blocks/pins), skip
            if (maze->nets[net_idx].routed_path.empty()) {
                cout << "Critical Error: Net " << maze->nets[net_idx].name << " is unreachable.\n";
                continue;
            }

            // 3. Rip up all victims so we can commit the forced path legally
            for (int v_id : victims_ids) {
                if (maze->nets[v_id].is_routed) {
                    maze->rip_up_net(v_id);
                    route_queue.push_back(v_id);
                }
            }
            maze->commit_net(net_idx);
        }
    }
    
    output(fout, maze);
    delete maze;
    return 0;
}